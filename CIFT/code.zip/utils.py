import sys
import errno
import os.path as osp
from torch.backends import cudnn
import random
import torch
import numpy as np
import math
import torchvision.transforms as T
import os
import re
import shutil
from tqdm import tqdm

class AverageMeter(object):
    def __init__(self):
        self.reset()
    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0
    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

def mkdir_if_missing(directory):
    if not osp.exists(directory):
        try:
            os.makedirs(directory)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise

class Logger(object):
    def __init__(self, fpath=None):
        self.console = sys.stdout
        self.file = None
        if fpath is not None:
            mkdir_if_missing(osp.dirname(fpath))
            self.file = open(fpath, 'w')
    def __del__(self):
        self.close()
    def __enter__(self):
        pass
    def __exit__(self, *args):
        self.close()
    def write(self, msg):
        self.console.write(msg)
        if self.file is not None:
            self.file.write(msg)
    def flush(self):
        self.console.flush()
        if self.file is not None:
            self.file.flush()
            os.fsync(self.file.fileno())
    def close(self):
        if self.file is not None:
            self.file.close()

class RandomErasing(object):
    def __init__(self, p=0.5, sl=0.02, sh=0.4, r1=0.3, r2=3.33):
        self.p = p
        self.sl = sl
        self.sh = sh
        self.r1 = r1
        self.r2 = r2
    def __call__(self, img):
        if np.random.uniform(0, 1) >= self.p:return img
        mean = [0.4914, 0.4822, 0.4465]#cifar10
        for attempt in range(100):
            area = img.size()[1] * img.size()[2]
            target_area = np.random.uniform(self.sl, self.sh) * area
            #用np.random和测试的random.random分开
            aspect_ratio = np.random.uniform(self.r1, self.r2)
            h = int(round(math.sqrt(target_area * aspect_ratio)))
            w = int(round(math.sqrt(target_area / aspect_ratio)))
            if w < img.size()[2] and h < img.size()[1]:
                x1 = np.random.randint(0, img.size()[1] - h)
                y1 = np.random.randint(0, img.size()[2] - w)
                img[0, x1:x1 + h, y1:y1 + w] = mean[0]
                img[1, x1:x1 + h, y1:y1 + w] = mean[1]
                img[2, x1:x1 + h, y1:y1 + w] = mean[2]
                return img
        return img

def set_seed(seed):
    np.random.seed(seed)
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    cudnn.benchmark = False
    cudnn.deterministic = True

def adjust_learning_rate(args, optimizer, epoch):
    lr = args.lr
    if epoch <= args.warmup_epoch:
        lr = lr * epoch  / args.warmup_epoch
    for scheduler_epoch in args.scheduler_epoch:
        if epoch > scheduler_epoch:
            lr = lr * 0.1
    optimizer.param_groups[0]['lr'] = lr
    for i in range(len(optimizer.param_groups) - 1):
        optimizer.param_groups[i + 1]['lr'] = args.dlr * lr
    return lr

def get_transform(args):
    transform_train = T.Compose([
        T.Resize((args.img_h, args.img_w)),
        T.Pad(10), T.RandomCrop((args.img_h, args.img_w)),
        T.RandomHorizontalFlip(), T.ToTensor(), RandomErasing(p=0.5),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    transform_test = T.Compose([
        T.Resize((args.img_h, args.img_w)), T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    return transform_train, transform_test

def get_grad_norm(parameters, norm_type=2):
    if isinstance(parameters, torch.Tensor):
        parameters = [parameters]
    parameters = list(filter(lambda p: p.grad is not None, parameters))
    norm_type = float(norm_type)
    total_norm = 0
    for p in parameters:
        param_norm = p.grad.data.norm(norm_type)
        total_norm += param_norm.item() ** norm_type
    total_norm = total_norm ** (1. / norm_type)
    return total_norm

def pre_process_sysu(dir="../data/sysu/"):
    if os.path.isdir(dir + 'train_rgb/') and os.path.isdir(dir + 'gallery_rgb/') \
            and os.path.isdir(dir + 'train_ir/') and os.path.isdir(dir + 'query_ir/'):
        return
    if not os.path.isdir(dir + 'train_rgb/'):
        os.makedirs(dir + 'train_rgb/')
    if not os.path.isdir(dir + 'gallery_rgb/'):
        os.makedirs(dir + 'gallery_rgb/')
    if not os.path.isdir(dir + 'train_ir/'):
        os.makedirs(dir + 'train_ir/')
    if not os.path.isdir(dir + 'query_ir/'):
        os.makedirs(dir + 'query_ir/')

    rgb_cameras = ['cam1', 'cam2', 'cam4', 'cam5']
    ir_cameras = ['cam3', 'cam6']

    file_path_train = os.path.join(dir, 'exp/train_id.txt')
    file_path_val = os.path.join(dir, 'exp/val_id.txt')
    file_path_test = os.path.join(dir, 'exp/test_id.txt')

    with open(file_path_train, 'r') as file:
        ids = file.read().splitlines()
        ids = [int(y) for y in ids[0].split(',')]
        id_train = ["%04d" % x for x in ids]

    with open(file_path_val, 'r') as file:
        ids = file.read().splitlines()
        ids = [int(y) for y in ids[0].split(',')]
        id_val = ["%04d" % x for x in ids]

    with open(file_path_test, 'r') as file:
        ids = file.read().splitlines()
        ids = [int(y) for y in ids[0].split(',')]
        id_test = ["%04d" % x for x in ids]
    # combine train and val split
    id_train.extend(id_val)

    train_rgb = []
    train_ir = []
    gallery_rgb = []
    query_ir = []

    for id in sorted(id_train):
        for cam in rgb_cameras:
            img_dir = os.path.join(dir, cam, id)
            if os.path.isdir(img_dir):
                new_files = sorted([img_dir + '/' + i for i in os.listdir(img_dir)])
                train_rgb.extend(new_files)
        for cam in ir_cameras:
            img_dir = os.path.join(dir, cam, id)
            if os.path.isdir(img_dir):
                new_files = sorted([img_dir + '/' + i for i in os.listdir(img_dir)])
                train_ir.extend(new_files)
    for id in sorted(id_test):
        for cam in rgb_cameras:
            img_dir = os.path.join(dir, cam, id)
            if os.path.isdir(img_dir):
                new_files = sorted([img_dir + '/' + i for i in os.listdir(img_dir)])
                gallery_rgb.extend(new_files)
        for cam in ir_cameras:
            img_dir = os.path.join(dir, cam, id)
            if os.path.isdir(img_dir):
                new_files = sorted([img_dir + '/' + i for i in os.listdir(img_dir)])
                query_ir.extend(new_files)

    for img_path in tqdm(train_rgb, desc='train_rgb'):
        pattern = re.compile(r'cam(\d+)/(\d+)/(\d+)')
        camid, pid, imgid = pattern.search(img_path).groups()
        path = dir + 'train_rgb/' + pid + '_c' + camid + '_' + imgid + '.jpg'
        shutil.copyfile(img_path, path)
    for img_path in tqdm(train_ir, desc='train_ir'):
        pattern = re.compile(r'cam(\d+)/(\d+)/(\d+)')
        camid, pid, imgid = pattern.search(img_path).groups()
        path = dir + 'train_ir/' + pid + '_c' + camid + '_' + imgid + '.jpg'
        shutil.copyfile(img_path, path)
    for img_path in tqdm(gallery_rgb, desc='gallery_rgb'):
        pattern = re.compile(r'cam(\d+)/(\d+)/(\d+)')
        camid, pid, imgid = pattern.search(img_path).groups()
        path = dir + 'gallery_rgb/' + pid + '_c' + camid + '_' + imgid + '.jpg'
        shutil.copyfile(img_path, path)
    for img_path in tqdm(query_ir, desc='query_ir'):
        pattern = re.compile(r'cam(\d+)/(\d+)/(\d+)')
        camid, pid, imgid = pattern.search(img_path).groups()
        path = dir + 'query_ir/' + pid + '_c' + camid + '_' + imgid + '.jpg'
        shutil.copyfile(img_path, path)