from torchvision import models
import torch.nn as nn
from torch.nn import init

def weights_init(m):
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        init.normal_(m.weight.data, 0, 0.001)

    elif classname.find('BatchNorm') != -1:
        init.normal_(m.weight.data, 1.0, 0.01)
        init.zeros_(m.bias.data)
        m.bias.requires_grad_(False)

class resnet(nn.Module):
    def __init__(self, class_num):
        super(resnet, self).__init__()
        model = models.resnet50(pretrained=True)
        for mo in model.layer4[0].modules():
            if isinstance(mo, nn.Conv2d):
                mo.stride = (1, 1)
        self.layer = nn.Sequential(*list(model.children())[:-2])
        dim = 2048
        self.bottleneck = nn.BatchNorm1d(dim)
        self.bottleneck.apply(weights_init)
        self.classifier = nn.Linear(dim, class_num, bias=False)
        self.classifier.apply(weights_init)
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.ignored_params = nn.ModuleList([self.bottleneck, self.classifier, ])

    def forward(self, x):
        x = self.layer(x)
        pool = self.avgpool(x).squeeze()
        feat = self.bottleneck(pool)
        if self.training:
            y = self.classifier(feat)
            return pool, y
        else:
            return pool, feat


if __name__ == '__main__':
    pass





