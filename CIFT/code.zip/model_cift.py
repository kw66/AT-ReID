from torchvision import models
import torch.nn as nn
from torch.nn import init
import torch

class Normalize(nn.Module):
    def __init__(self, power=2):
        super(Normalize, self).__init__()
        self.power = power

    def forward(self, x):
        norm = x.pow(self.power).sum(dim=-1, keepdim=True).pow(1./self.power)
        out = x.div(norm)
        return out

def weights_init(m):
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        init.normal_(m.weight.data, 0, 0.001)

    elif classname.find('BatchNorm') != -1:
        init.normal_(m.weight.data, 1.0, 0.01)
        init.zeros_(m.bias.data)
        m.bias.requires_grad_(False)

class cift(nn.Module):
    def __init__(self):
        super(cift, self).__init__()
        self.l2norm = Normalize(2)
        self.c = nn.Parameter(torch.ones(64, 1))
        self.k = nn.Parameter(torch.zeros(64, 2048))

    def forward(self, x, num_rgb=32, mode='r2i'):
        num = x.shape[0]
        num_ir = num - num_rgb
        s = self.l2norm(x) @ self.l2norm(x).T
        s_hom = (s / 0.4).exp()
        s_het = (s / 0.2).exp()
        mask_hom = torch.zeros_like(s)
        mask_het = torch.zeros_like(s)
        cmask = torch.ones_like(s) - torch.eye(num).type_as(x)
        if mode == 'r2i':
            mask_hom[num_rgb:, num_rgb:] = 1
            mask_het[:num_rgb, num_rgb:] = 1
            mask_het[:num_rgb, :num_rgb] = torch.eye(num_rgb).type_as(x)
        if mode == 'i2r':
            mask_hom[:num_rgb, :num_rgb] = 1
            mask_het[num_rgb:, :num_rgb] = 1
            mask_het[num_rgb:, num_rgb:] = torch.eye(num_ir).type_as(x)
        s_hom = s_hom * mask_hom
        s_het = s_het * mask_het
        topk_hom = s_hom.topk(k=4 + 1, dim=1)[0][:, -1]
        topk_hom = ((s_hom - topk_hom.unsqueeze(1)) > 0).float()
        topk_het = s_het.topk(k=4 + 1, dim=1)[0][:, -1]
        topk_het = ((s_het - topk_het.unsqueeze(1)) > 0).float()
        a_hom = s_hom * topk_hom
        a_het = s_het * topk_het
        a = a_hom + a_het
        a = a / (a.sum(dim=-1, keepdim=True))
        gx = a @ x
        if self.training:
            t = 10
            for i in range(t):
                cx = torch.ones_like(x).normal_(0, 1) * self.c.clamp(0) + self.k
                cs = self.l2norm(cx) @ self.l2norm(cx).T
                cs_hom = (cs / 0.4).exp()
                cs_het = (cs / 0.2).exp()
                cs_hom = cs_hom * mask_hom * cmask
                cs_het = cs_het * mask_het * cmask
                ctopk_hom = cs_hom.topk(k=4 + 1, dim=1)[0][:, -1]
                ctopk_hom = ((cs_hom - ctopk_hom.unsqueeze(1)) > 0).float()
                ctopk_het = cs_het.topk(k=4 + 1, dim=1)[0][:, -1]
                ctopk_het = ((cs_het - ctopk_het.unsqueeze(1)) > 0).float()
                ca_hom = cs_hom * ctopk_hom
                ca_het = cs_het * ctopk_het
                ca = ca_hom + ca_het
                ca = ca / (ca.sum(dim=-1, keepdim=True))
                if i == 0:
                    cgx = ca @ x / t
                else:
                    cgx = cgx + ca @ x / t
            return gx, cgx
        else:
            return gx

class resnet(nn.Module):
    def __init__(self, class_num):
        super(resnet, self).__init__()
        model = models.resnet50(pretrained=True)
        for mo in model.layer4[0].modules():
            if isinstance(mo, nn.Conv2d):
                mo.stride = (1, 1)
        self.layer = nn.Sequential(*list(model.children())[:-2])
        dim = 2048
        self.bottleneck_b = nn.BatchNorm1d(dim)
        self.bottleneck_b.apply(weights_init)
        self.bottleneck_r2i = nn.BatchNorm1d(dim)
        self.bottleneck_r2i.apply(weights_init)
        self.bottleneck_i2r = nn.BatchNorm1d(dim)
        self.bottleneck_i2r.apply(weights_init)

        self.classifier_b = nn.Linear(dim, class_num, bias=False)
        self.classifier_b.apply(weights_init)
        self.classifier_r2i = nn.Linear(dim, class_num, bias=False)
        self.classifier_r2i.apply(weights_init)
        self.classifier_i2r = nn.Linear(dim, class_num, bias=False)
        self.classifier_i2r.apply(weights_init)

        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.ignored_params = nn.ModuleList([self.bottleneck_b, self.classifier_b,
                                             self.bottleneck_r2i, self.classifier_r2i,
                                             self.bottleneck_i2r, self.classifier_i2r, ])
        self.l2norm = Normalize(2)
        self.ignored_params.apply(weights_init)
        self.cift = cift()

    def forward(self, x):
        x = self.layer(x)
        pool = self.avgpool(x).squeeze()
        f_b = self.bottleneck_b(pool)
        f_r2i = self.bottleneck_r2i(pool)
        f_i2r = self.bottleneck_i2r(pool)
        if self.training:
            gf_r2i, cgf_r2i = self.cift(f_r2i, 32, 'r2i')
            gf_i2r, cgf_i2r = self.cift(f_i2r, 32, 'i2r')
            y = self.classifier_b(f_b)
            gy_r2i = self.classifier_r2i(gf_r2i)
            gy_i2r = self.classifier_i2r(gf_i2r)
            cgy_r2i = self.classifier_r2i(gf_r2i - cgf_r2i)
            cgy_i2r = self.classifier_i2r(gf_i2r - cgf_i2r)
            return pool, y, gy_r2i, gy_i2r, cgy_r2i, cgy_i2r
        else:
            return f_r2i, f_i2r


if __name__ == '__main__':
    pass





